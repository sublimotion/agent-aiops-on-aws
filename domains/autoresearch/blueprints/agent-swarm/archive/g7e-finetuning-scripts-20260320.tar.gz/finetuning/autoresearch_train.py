#!/usr/bin/env python3
"""Autoresearch loop: emotion classification fine-tuning with Unsloth + LoRA."""

import os, sys, time, subprocess, warnings, gc
warnings.filterwarnings("ignore")
os.environ["PYTHONWARNINGS"] = "ignore"
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

import torch
from pathlib import Path
from sentiment.config import ExperimentConfig, sample_config, DEFAULT_CONFIG
from sentiment.data import load_dataset as load_sentiment_data, train_val_split, format_for_training
from sentiment.evaluate import evaluate_model, print_eval_summary

DATASET_PATH = "sentiment/emotion_data.csv"
RESULTS_FILE = "results.tsv"
LABELS = ["joy", "sadness", "anger", "fear", "love", "surprise"]
OUTPUT_DIR = "output"
BEST_DIR = "best_adapter"
VAL_EVAL_SIZE = 300  # Use subset for fast eval


def log_result(commit, val_metric, memory_gb, status, description):
    with open(RESULTS_FILE, "a") as f:
        f.write(f"{commit}\t{val_metric:.4f}\t{memory_gb:.2f}\t{status}\t{description}\n")
    print(f"\n>> Logged: {commit[:7]} | macro_f1={val_metric:.4f} | {status} | {description}")


def get_commit():
    r = subprocess.run(["git", "rev-parse", "--short", "HEAD"], capture_output=True, text=True)
    return r.stdout.strip()


def git_commit(msg):
    subprocess.run(["git", "add", "results.tsv", "sentiment/config.py"], capture_output=True)
    subprocess.run(["git", "commit", "-m", msg, "--allow-empty"], capture_output=True)
    return get_commit()


def git_revert():
    subprocess.run(["git", "reset", "--hard", "HEAD~1"], capture_output=True)


def cleanup():
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats()


def train_and_eval(config, train_convs, val_convs):
    from unsloth import FastLanguageModel
    from trl import SFTTrainer
    from transformers import TrainingArguments
    from datasets import Dataset

    cleanup()
    print(f"\nTRAINING: {config.base_model} | {config.describe()}")

    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name=config.base_model, max_seq_length=config.max_seq_length,
        dtype=None, load_in_4bit=True,
    )
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    model = FastLanguageModel.get_peft_model(
        model, r=config.lora_r,
        target_modules=["q_proj","k_proj","v_proj","o_proj","gate_proj","up_proj","down_proj"],
        lora_alpha=config.lora_alpha, lora_dropout=config.lora_dropout,
        bias="none", use_gradient_checkpointing="unsloth", random_state=42,
    )

    # Format data
    def fmt(examples):
        return {"text": [
            tokenizer.apply_chat_template(c, tokenize=False, add_generation_prompt=False)
            for c in examples["conversations"]
        ]}

    train_ds = Dataset.from_list(train_convs)
    train_ds = train_ds.map(fmt, batched=True, remove_columns=train_ds.column_names)

    trainer = SFTTrainer(
        model=model, tokenizer=tokenizer, train_dataset=train_ds,
        max_seq_length=config.max_seq_length,
        formatting_func=lambda x: x["text"],
        args=TrainingArguments(
            per_device_train_batch_size=config.per_device_batch,
            gradient_accumulation_steps=config.grad_accum_steps,
            warmup_ratio=config.warmup_ratio, num_train_epochs=config.num_epochs,
            learning_rate=config.learning_rate, weight_decay=config.weight_decay,
            lr_scheduler_type=config.lr_scheduler, optim=config.optim,
            fp16=not torch.cuda.is_bf16_supported(),
            bf16=torch.cuda.is_bf16_supported(),
            logging_steps=50, save_strategy="no", output_dir=OUTPUT_DIR,
            seed=42, report_to="none",
        ),
    )

    t0 = time.time()
    trainer.train()
    print(f"Training: {time.time()-t0:.1f}s")
    mem = torch.cuda.max_memory_allocated() / 1e9

    model.save_pretrained(OUTPUT_DIR)
    tokenizer.save_pretrained(OUTPUT_DIR)

    FastLanguageModel.for_inference(model)
    results = evaluate_model(model, tokenizer, val_convs[:VAL_EVAL_SIZE], LABELS)
    print_eval_summary(results)

    f1 = results["macro_f1"]
    del model, tokenizer, trainer
    cleanup()
    return f1, mem


def main():
    if not Path(RESULTS_FILE).exists():
        with open(RESULTS_FILE, "w") as f:
            f.write("commit\tval_metric\tmemory_gb\tstatus\tdescription\n")

    print("Loading data...")
    df = load_sentiment_data(DATASET_PATH)
    train_df, val_df = train_val_split(df, val_fraction=0.15, seed=42)
    train_convs = format_for_training(train_df, LABELS, include_category=False)
    val_convs = format_for_training(val_df, LABELS, include_category=False)
    print(f"Train: {len(train_convs)} | Val: {len(val_convs)}")

    # Zero-shot baseline (small subset)
    print("\n=== ZERO-SHOT BASELINE ===")
    from unsloth import FastLanguageModel
    model, tok = FastLanguageModel.from_pretrained(
        model_name="unsloth/Qwen3-0.6B", max_seq_length=512, dtype=None, load_in_4bit=True)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token
    FastLanguageModel.for_inference(model)
    res = evaluate_model(model, tok, val_convs[:VAL_EVAL_SIZE], LABELS)
    print_eval_summary(res)
    baseline_f1 = res["macro_f1"]
    del model, tok; cleanup()
    log_result(get_commit(), baseline_f1, 0.7, "baseline", f"Zero-shot Qwen3-0.6B ({VAL_EVAL_SIZE} val)")

    best_f1 = baseline_f1
    best_config = DEFAULT_CONFIG
    exp = 0

    while True:
        exp += 1
        if exp == 1:
            config = DEFAULT_CONFIG
            desc = "DEFAULT_CONFIG"
        else:
            config = sample_config(best_config, n_changes=2)
            changed = [f"{k}={getattr(config,k)}" for k in vars(config)
                      if k not in ("seed","logging_steps") and getattr(config,k) != getattr(best_config,k)]
            desc = ", ".join(changed) if changed else "no change"

        print(f"\n{'='*60}\nEXPERIMENT {exp} | Best: {best_f1:.4f} | {desc}\n{'='*60}")
        commit = git_commit(f"Exp {exp}: {desc}")

        try:
            f1, mem = train_and_eval(config, train_convs, val_convs)
            if f1 > best_f1:
                best_f1 = f1
                best_config = config
                log_result(commit, f1, mem, "keep", desc)
                os.makedirs(BEST_DIR, exist_ok=True)
                subprocess.run(["cp", "-r", f"{OUTPUT_DIR}/.", f"{BEST_DIR}/"], check=False)
                print(f"\n** NEW BEST: macro_f1={f1:.4f} **")
            else:
                log_result(commit, f1, mem, "discard", desc)
                git_revert()
        except Exception as e:
            err = str(e)[:200]
            print(f"\nFAILED: {err}")
            log_result(commit, 0.0, 0.0, "failed", f"Error: {err}")
            git_revert()
            cleanup()

        time.sleep(2)


if __name__ == "__main__":
    main()
