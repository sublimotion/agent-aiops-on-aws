# Autoresearch: Fine-Tuning Recipes

## Hardware
- 4x NVIDIA RTX PRO 6000 Blackwell (96 GB GDDR7 each, sm_120)
- Instance: g7e.24xlarge
- Use single GPU (CUDA_VISIBLE_DEVICES=0)

## Environment
- Python venv: `.venv` — always run `source .venv/bin/activate` before any Python command
- Unsloth + PEFT + TRL + bitsandbytes + datasets + scikit-learn installed

## Dataset
- **File**: `sentiment/emotion_data.csv` — 20,000 samples, 6 emotion classes
- **Labels**: joy (6761), sadness (5797), anger (2709), fear (2373), love (1641), surprise (719)
- **Format**: CSV with `text` and `label` columns (no category column)
- **Class imbalance**: surprise is 14x rarer than joy — macro F1 penalizes poor minority-class performance

## The Experiment

Fine-tune Qwen3.5 models with Unsloth LoRA on emotion classification. Optimize **macro F1**.

### Fixed Files (DO NOT EDIT)
- `sentiment/evaluate.py` — macro F1 metric, per-class metrics, inference harness
- `sentiment/data.py` — data loading, train/val split, chat template formatting
- `sentiment/emotion_data.csv` — the dataset

### Editable Files
- `sentiment/config.py` — search space, ExperimentConfig, sample_config()
- Any training script you create

### Key Functions
```python
from sentiment.config import ExperimentConfig, sample_config, DEFAULT_CONFIG
from sentiment.data import load_dataset, train_val_split, format_for_training
from sentiment.evaluate import evaluate_model, print_eval_summary
```

`load_dataset("sentiment/emotion_data.csv")` returns a DataFrame.
`train_val_split(df, val_fraction=0.15)` splits with stratification.
`format_for_training(train_df, labels, include_category=False)` creates chat conversations.
`evaluate_model(model, tokenizer, val_data, labels)` returns dict with `macro_f1`, `accuracy`, etc.

### Metric
- **macro_f1** on held-out validation set (higher is better)
- This averages F1 across all 6 classes equally — rewards good performance on rare classes (surprise, love)

### Search Space (sentiment/config.py)
- LoRA: r=[4,8,16,32,64], alpha=[8,16,32,64,128], dropout=[0,0.05,0.1]
- Training: lr=[5e-5..1e-3], epochs=[1..5], batch=[2,4,8,16], grad_accum=[1,2,4,8]
- Optimizer: adamw_8bit, adamw_torch, paged_adamw_8bit
- Scheduler: linear, cosine, constant_with_warmup
- Seq length: [256, 512, 768, 1024]
- Model: Qwen3-0.6B, Qwen3-1.7B

### Loop Protocol
1. Create branch: `git checkout -b autoresearch/finetune`
2. Create `results.tsv` with header: `commit\tval_metric\tmemory_gb\tstatus\tdescription`
3. Establish baseline: evaluate Qwen3-0.6B zero-shot on val set (no fine-tuning)
4. Run first LoRA training with DEFAULT_CONFIG, evaluate, log as first experiment
5. LOOP: use sample_config(best_config, n_changes=2) to mutate → train → evaluate → keep if macro_f1 improved, revert if not → log to results.tsv → git commit
6. Each experiment: ~2-5 min training + ~1-2 min eval

### Training Pattern
```python
from unsloth import FastLanguageModel
from trl import SFTTrainer
from transformers import TrainingArguments

model, tokenizer = FastLanguageModel.from_pretrained(
    model_name="unsloth/Qwen3-0.6B",
    max_seq_length=512, dtype=None, load_in_4bit=True,
)
model = FastLanguageModel.get_peft_model(
    model, r=16,
    target_modules=["q_proj","k_proj","v_proj","o_proj","gate_proj","up_proj","down_proj"],
    lora_alpha=16, lora_dropout=0.0, bias="none",
    use_gradient_checkpointing="unsloth", random_state=42,
)
# After training, switch to inference:
FastLanguageModel.for_inference(model)
```

### Rules
- NEVER edit evaluate.py, data.py, or the CSV dataset
- NEVER stop — run experiments until manually interrupted
- Log EVERY experiment to results.tsv (including crashes)
- Git commit before each run, `git reset --hard HEAD~1` on regression
- Time budget: 10 min max per experiment
- With 20K samples and 6 imbalanced classes, watch for: overfitting on majority classes (joy/sadness), poor recall on surprise/love
- If macro_f1 plateaus, try: switching to 1.7B model, aggressive alpha scaling, targeting embed/lm_head modules, longer sequences, different optimizers
