#!/bin/bash
set -e
cd /mnt/nvme/sera-scripts
pkill -f sera-datagen 2>/dev/null || true
rm -rf /mnt/nvme/sera-workspaces/django__*
mkdir -p /mnt/nvme/sera-data/django-v5

python3 sera-datagen.py \
    --endpoint http://localhost:8000 \
    --model devstral-small-2 \
    --issues /mnt/nvme/sera-data/django_issues_v3.jsonl \
    --max-concurrent 1 \
    --output-dir /mnt/nvme/sera-data/django-v5 \
    --workspace-dir /mnt/nvme/sera-workspaces
