from datasets import load_dataset
import json

print("Loading CoderForge filtered_reward1...")
ds = load_dataset("togethercomputer/CoderForge-Preview", "trajectories", split="filtered_reward1")
print(f"Loaded {len(ds)} examples")
print(f"Columns: {ds.column_names}")

ex = ds[0]
msgs = json.loads(ex["messages"]) if isinstance(ex["messages"], str) else ex["messages"]
print(f"Messages count: {len(msgs)}, first role: {msgs[0].get('role', '?')}")

out_path = "/mnt/nvme/sera-data/coderforge/train_trl.jsonl"
print(f"Writing to {out_path}...")
count = 0
with open(out_path, "w") as f:
    for ex in ds:
        msgs = json.loads(ex["messages"]) if isinstance(ex["messages"], str) else ex["messages"]
        row = {"messages": msgs}
        f.write(json.dumps(row) + "\n")
        count += 1
        if count % 10000 == 0:
            print(f"  Written {count}...")
print(f"Done: {count} examples written")
