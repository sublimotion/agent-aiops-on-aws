path = "/usr/local/lib/python3.12/dist-packages/vllm/entrypoints/openai/responses/utils.py"
with open(path) as f:
    code = f.read()

# Fix construct_tool_dicts to only convert function tools
old = """    else:
        tool_dicts = [
            convert_tool_responses_to_completions_format(tool.model_dump())
            for tool in tools
        ]"""

new = """    else:
        tool_dicts = [
            convert_tool_responses_to_completions_format(tool.model_dump())
            for tool in tools
            if tool.type == "function"
        ]
        if not tool_dicts:
            tool_dicts = None"""

if old in code:
    code = code.replace(old, new)
    with open(path, "w") as f:
        f.write(code)
    print("Patch 4 (filter non-function tools) applied")
else:
    print("WARNING: construct_tool_dicts patch target not found")
