#!/bin/bash
set -e

python3 /tmp/patch_converters.py
python3 /tmp/patch_utils.py
python3 /tmp/patch_tools.py

exec vllm serve /mnt/nvme/models/devstral-small-2-fp8 \
  --served-model-name devstral-small-2 \
  --tool-call-parser mistral \
  --enable-auto-tool-choice \
  --max-model-len 131072 \
  --tensor-parallel-size 2 \
  --enable-prefix-caching \
  --max-num-seqs 4 \
  --enable-chunked-prefill \
  --gpu-memory-utilization 0.90 \
  --port 8000
