#!/usr/bin/env python3
"""Proxy that fixes vLLM Responses API streaming for tool calls.

Handles two issues with vLLM v0.16.0:
1. Streaming path doesn't parse Mistral tool calls → convert to non-streaming
2. Multi-turn input from Codex has extra fields vLLM can't parse → normalize input items
"""
import http.server
import json
import urllib.request
import sys
import socketserver
import traceback

UPSTREAM = "http://localhost:8000"

def normalize_content(content):
    """Normalize content from Codex format to vLLM-compatible format."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for p in content:
            if isinstance(p, dict):
                # input_text -> text
                text = p.get("text", p.get("input_text", ""))
                parts.append(text)
            elif isinstance(p, str):
                parts.append(p)
        return " ".join(parts) if parts else ""
    return str(content) if content else ""


def normalize_input_item(item):
    """Normalize a Codex input item for vLLM compatibility."""
    if not isinstance(item, dict):
        return item

    item_type = item.get("type", "")

    if item_type == "message":
        # Codex sends {"type":"message","role":"developer","content":[{"type":"input_text","text":"..."}]}
        role = item.get("role", "user")
        if role == "developer":
            role = "system"
        content = normalize_content(item.get("content", ""))
        result = {"type": "message", "role": role, "content": content}
        # Copy optional fields
        if "name" in item:
            result["name"] = item["name"]
        return result

    elif item_type == "function_call":
        # Keep as-is but clean up
        result = {
            "type": "function_call",
            "call_id": item.get("call_id", ""),
            "name": item.get("name", ""),
            "arguments": item.get("arguments", "{}"),
        }
        if "id" in item:
            result["id"] = item["id"]
        if "status" in item:
            result["status"] = item["status"]
        return result

    elif item_type == "function_call_output":
        result = {
            "type": "function_call_output",
            "call_id": item.get("call_id", ""),
            "output": str(item.get("output", "")),
        }
        if "id" in item:
            result["id"] = item["id"]
        return result

    # Pass through other types
    return item


def normalize_request(data):
    """Normalize the full request body."""
    if "input" in data and isinstance(data["input"], list):
        data["input"] = [normalize_input_item(item) for item in data["input"]]
    # Filter out non-function tools
    if "tools" in data and isinstance(data["tools"], list):
        data["tools"] = [t for t in data["tools"] if t.get("type") == "function"]
        if not data["tools"]:
            del data["tools"]
    return data


class ReuseAddrServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    allow_reuse_port = True


class ResponsesProxy(http.server.BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        sys.stderr.write(f"[proxy] {fmt % args}\n")
        sys.stderr.flush()

    def do_GET(self):
        try:
            req = urllib.request.Request(f"{UPSTREAM}{self.path}")
            for h in ("Authorization", "Content-Type"):
                if h in self.headers:
                    req.add_header(h, self.headers[h])
            with urllib.request.urlopen(req) as resp:
                body = resp.read()
                self.send_response(resp.status)
                self.send_header("Content-Type", resp.headers.get("Content-Type", "application/json"))
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
        except urllib.error.HTTPError as e:
            body = e.read()
            self.send_response(e.code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        except Exception:
            traceback.print_exc()
            self.send_response(502)
            self.end_headers()

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length)

        try:
            data = json.loads(body)
        except json.JSONDecodeError:
            data = None

        is_responses = "/v1/responses" in self.path

        if is_responses and data:
            data = normalize_request(data)
            is_streaming = data.get("stream", False)
            if is_streaming:
                self._handle_streaming_responses(data)
            else:
                self._proxy_post(json.dumps(data).encode())
        else:
            self._proxy_post(body)

    def _proxy_post(self, body):
        try:
            req = urllib.request.Request(
                f"{UPSTREAM}{self.path}", data=body, method="POST",
            )
            for h in ("Authorization", "Content-Type", "Accept"):
                if h in self.headers:
                    req.add_header(h, self.headers[h])
            with urllib.request.urlopen(req, timeout=600) as resp:
                resp_body = resp.read()
                self.send_response(resp.status)
                for key in ("Content-Type", "Content-Length"):
                    val = resp.headers.get(key)
                    if val:
                        self.send_header(key, val)
                self.end_headers()
                self.wfile.write(resp_body)
        except urllib.error.HTTPError as e:
            body = e.read()
            self.send_response(e.code)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(body)
        except Exception:
            traceback.print_exc()
            self.send_response(502)
            self.end_headers()

    def _handle_streaming_responses(self, data):
        data["stream"] = False
        body = json.dumps(data).encode()

        try:
            req = urllib.request.Request(
                f"{UPSTREAM}/v1/responses", data=body, method="POST",
            )
            req.add_header("Content-Type", "application/json")
            if "Authorization" in self.headers:
                req.add_header("Authorization", self.headers["Authorization"])
            with urllib.request.urlopen(req, timeout=600) as resp:
                resp_body = resp.read()
                response = json.loads(resp_body)
        except urllib.error.HTTPError as e:
            err_body = e.read()
            self.send_response(e.code)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(err_body)
            return
        except Exception as e:
            traceback.print_exc()
            err = json.dumps({"error": {"message": str(e)}}).encode()
            self.send_response(500)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(err)
            return

        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()

        seq = [0]

        def emit(event_type, event_data):
            event_data["sequence_number"] = seq[0]
            event_data["type"] = event_type
            line = f"event: {event_type}\ndata: {json.dumps(event_data)}\n\n"
            self.wfile.write(line.encode())
            self.wfile.flush()
            seq[0] += 1

        resp_shell = {k: v for k, v in response.items() if k != "output"}
        resp_shell["output"] = []
        resp_shell["status"] = "in_progress"
        emit("response.created", {"response": resp_shell})
        emit("response.in_progress", {"response": resp_shell})

        for oi, item in enumerate(response.get("output", [])):
            item_type = item.get("type", "message")

            if item_type == "function_call":
                emit("response.output_item.added", {
                    "item": dict(item, status="in_progress", arguments=""),
                    "output_index": oi,
                })
                args = item.get("arguments", "")
                if args:
                    emit("response.function_call_arguments.delta", {
                        "delta": args, "item_id": item.get("id", ""), "output_index": oi,
                    })
                    emit("response.function_call_arguments.done", {
                        "arguments": args, "item_id": item.get("id", ""), "output_index": oi,
                    })
                emit("response.output_item.done", {
                    "item": dict(item, status="completed"), "output_index": oi,
                })

            elif item_type == "message":
                emit("response.output_item.added", {
                    "item": dict(item, status="in_progress"), "output_index": oi,
                })
                for ci, content in enumerate(item.get("content", [])):
                    text = content.get("text", "")
                    emit("response.content_part.added", {
                        "content_index": ci, "item_id": item.get("id", ""),
                        "output_index": oi,
                        "part": {"annotations": [], "text": "", "type": "output_text", "logprobs": []},
                    })
                    if text:
                        emit("response.output_text.delta", {
                            "content_index": ci, "delta": text,
                            "item_id": item.get("id", ""), "logprobs": [], "output_index": oi,
                        })
                        emit("response.output_text.done", {
                            "content_index": ci, "item_id": item.get("id", ""),
                            "logprobs": [], "output_index": oi, "text": text,
                        })
                    emit("response.content_part.done", {
                        "content_index": ci, "item_id": item.get("id", ""),
                        "output_index": oi, "part": content,
                    })
                emit("response.output_item.done", {
                    "item": dict(item, status="completed"), "output_index": oi,
                })

        emit("response.completed", {"response": dict(response, status="completed")})


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8001
    server = ReuseAddrServer(("0.0.0.0", port), ResponsesProxy)
    print(f"Responses proxy listening on :{port} -> {UPSTREAM}", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
