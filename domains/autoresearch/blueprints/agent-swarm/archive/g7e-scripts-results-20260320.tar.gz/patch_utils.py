path = "/usr/local/lib/python3.12/dist-packages/vllm/entrypoints/openai/responses/utils.py"
with open(path) as f:
    code = f.read()

helper = '''
def _normalize_msg_for_mistral(msg):
    """Strip Responses API extra fields and normalize content format for mistral_common."""
    if not isinstance(msg, dict):
        return msg
    clean = {}
    for k in ("role", "content", "tool_calls", "tool_call_id", "name"):
        if k in msg:
            clean[k] = msg[k]
    if clean.get("role") == "developer":
        clean["role"] = "system"
    c = clean.get("content")
    if isinstance(c, list):
        parts = []
        for p in c:
            if isinstance(p, dict):
                parts.append(p.get("text", ""))
            elif isinstance(p, str):
                parts.append(p)
        clean["content"] = " ".join(parts)
    return clean


'''

if "def _normalize_msg_for_mistral" not in code:
    marker = "def construct_input_messages"
    idx = code.find(marker)
    if idx > 0:
        line_start = code.rfind("\n", 0, idx)
        code = code[:line_start] + "\n" + helper + code[line_start:]
        print("Helper function injected")
    else:
        print("ERROR: construct_input_messages not found")

    old_ext = "messages.extend(input_messages)"
    new_ext = "messages.extend([_normalize_msg_for_mistral(m) for m in input_messages])"
    if old_ext in code:
        code = code.replace(old_ext, new_ext, 1)
        print("Extend call patched")

    with open(path, "w") as f:
        f.write(code)
    print("Patch 3 (utils) complete")
else:
    print("Patch 3 already applied")
