#!/usr/bin/env python3
"""Compare all Phase 2 + Phase 2b harness results."""
import json

def load_eval(path):
    results = {}
    for line in open(path):
        r = json.loads(line)
        results[r["instance_id"]] = r.get("tests_pass", False)
    return results

harnesses = {
    "SERA": load_eval("results/eval_sera.jsonl"),
    "LangGraph": load_eval("results/eval_langgraph.jsonl"),
    "Hashline": load_eval("results/eval_ohmypi.jsonl"),
    "PiAgent": load_eval("results/eval_piagent.jsonl"),
}

all_ids = sorted(set(iid for h in harnesses.values() for iid in h.keys()))

# Header
hdr = f"{'instance_id':45s}"
for name in harnesses:
    hdr += f" {name[:6]:>6s}"
print(hdr)
print("-" * (45 + 7 * len(harnesses)))

# Rows (only show issues where at least one harness passes)
for iid in all_ids:
    vals = {name: h.get(iid) for name, h in harnesses.items()}
    if any(vals.values()):
        row = f"{iid:45s}"
        for name in harnesses:
            v = vals[name]
            if v:
                row += f" {'PASS':>6s}"
            elif iid in harnesses[name]:
                row += f" {'fail':>6s}"
            else:
                row += f" {'  -':>6s}"
        print(row)

# Summary
print()
print("=" * 60)
print(f"{'Harness':15s} {'Pass':>6s} {'Rate':>8s} {'Patches':>8s} {'Prec':>8s}")
print("-" * 60)
for name, h in harnesses.items():
    total_patches = len(h)
    passes = sum(1 for v in h.values() if v)
    rate = 100 * passes / 50
    prec = 100 * passes / total_patches if total_patches else 0
    print(f"{name:15s} {passes:>6d} {rate:>7.1f}% {total_patches:>8d} {prec:>7.1f}%")

# Union
union = set()
for h in harnesses.values():
    for iid, v in h.items():
        if v:
            union.add(iid)
print(f"{'Union':15s} {len(union):>6d} {100*len(union)/50:>7.1f}%")

# Unique passes
print()
print("Unique passes (solved by only one harness):")
for name, h in harnesses.items():
    uniq = [iid for iid in all_ids
            if h.get(iid)
            and not any(other.get(iid) for oname, other in harnesses.items() if oname != name)]
    if uniq:
        print(f"  {name}: {uniq}")

# Pairwise overlap
print()
print("Pairwise overlap:")
names = list(harnesses.keys())
for i, n1 in enumerate(names):
    for n2 in names[i+1:]:
        both = sum(1 for iid in all_ids if harnesses[n1].get(iid) and harnesses[n2].get(iid))
        print(f"  {n1} & {n2}: {both}")
