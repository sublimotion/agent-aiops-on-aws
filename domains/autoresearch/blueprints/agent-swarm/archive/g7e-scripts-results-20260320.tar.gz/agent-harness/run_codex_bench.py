#!/usr/bin/env python3
"""Run Codex CLI harness against SWE-bench Lite 50-issue subset."""

import json
import os
import random
import shutil
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

from datasets import load_dataset

WORKSPACE_ROOT = Path("/mnt/nvme/sera-workspaces")
REPO_CACHE = WORKSPACE_ROOT / "_repo_cache"
RESULTS_DIR = Path("/mnt/nvme/agent-harness/results")
PATCHES_DIR = Path("/mnt/nvme/agent-harness/patches")
ADAPTER = Path("/mnt/nvme/agent-harness/adapters/run_codex.sh")

ENDPOINT = os.environ.get("ENDPOINT", "http://localhost:8001")
MODEL = os.environ.get("MODEL", "devstral-small-2")


def select_subset(dataset, n=50, seed=42):
    rng = random.Random(seed)
    by_repo = {}
    for i, item in enumerate(dataset):
        repo = item["repo"]
        if repo not in by_repo:
            by_repo[repo] = []
        by_repo[repo].append(i)

    selected = []
    total = len(dataset)
    for repo, indices in by_repo.items():
        count = max(1, round(n * len(indices) / total))
        sampled = rng.sample(indices, min(count, len(indices)))
        selected.extend(sampled)

    rng.shuffle(selected)
    return selected[:n]


def setup_workspace(item):
    """Clone/copy repo and checkout base_commit."""
    instance_id = item["instance_id"]
    repo = item["repo"]
    base_commit = item["base_commit"]

    ws = WORKSPACE_ROOT / instance_id.replace("/", "__")
    if ws.exists():
        shutil.rmtree(ws)

    # Check cache
    repo_dir = REPO_CACHE / repo.replace("/", "__")
    if repo_dir.exists():
        shutil.copytree(repo_dir, ws)
    else:
        # Clone fresh
        url = f"https://github.com/{repo}.git"
        subprocess.run(["git", "clone", "--quiet", url, str(ws)],
                      capture_output=True, timeout=120)
        # Cache it
        REPO_CACHE.mkdir(parents=True, exist_ok=True)
        shutil.copytree(ws, repo_dir)

    # Checkout base commit
    subprocess.run(["git", "checkout", "-f", base_commit],
                  capture_output=True, cwd=ws, timeout=60)
    subprocess.run(["git", "clean", "-fdx"],
                  capture_output=True, cwd=ws, timeout=60)

    return str(ws)


def run_codex_on_issue(item, workspace):
    """Run the Codex adapter on a single issue."""
    instance_id = item["instance_id"]
    problem = item["problem_statement"]
    test_cmd = item.get("test_cmd", "")
    repo = item["repo"]

    env = os.environ.copy()
    env.update({
        "WORKSPACE": workspace,
        "ENDPOINT": ENDPOINT,
        "MODEL": MODEL,
        "ISSUE_ID": instance_id,
        "PROBLEM_STATEMENT": problem[:10000],
        "TEST_CMD": test_cmd,
        "REPO": repo,
        "OPENAI_API_KEY": "dummy",
    })

    start = time.monotonic()
    try:
        proc = subprocess.run(
            ["bash", str(ADAPTER)],
            capture_output=True, text=True,
            timeout=600,
            cwd=workspace,
            env=env,
        )

        lines = [l.strip() for l in proc.stdout.strip().split("\n") if l.strip()]
        if lines:
            try:
                result = json.loads(lines[-1])
            except json.JSONDecodeError:
                result = {"error": f"parse error: {lines[-1][:200]}"}
        else:
            result = {"error": "no output"}

        if proc.returncode != 0 and "error" not in result:
            result["error"] = f"exit {proc.returncode}: {proc.stderr[:300]}"

    except subprocess.TimeoutExpired:
        result = {"error": "timeout 600s"}
    except Exception as e:
        result = {"error": str(e)[:500]}

    elapsed = (time.monotonic() - start) * 1000

    # Check for generated patch
    diff = subprocess.run(["git", "diff"], capture_output=True, text=True, cwd=workspace)
    has_patch = len(diff.stdout.strip()) > 0

    if has_patch:
        # Save the patch
        PATCHES_DIR.mkdir(parents=True, exist_ok=True)
        patch_file = PATCHES_DIR / f"codex__{instance_id.replace('/', '__')}.diff"
        with open(patch_file, "w") as f:
            f.write(diff.stdout)

    result.update({
        "instance_id": instance_id,
        "harness": "codex",
        "total_latency_ms": round(elapsed),
        "has_patch": has_patch,
    })

    return result


def main():
    resume_from = int(sys.argv[1]) if len(sys.argv) > 1 else 0

    print(f"=== Codex CLI Benchmark ===")
    print(f"Endpoint: {ENDPOINT}, Model: {MODEL}")
    print(f"Resume from: {resume_from}")
    print(f"Time: {datetime.now().isoformat()}")

    dataset = load_dataset("princeton-nlp/SWE-bench_Lite", split="test")
    indices = select_subset(dataset, n=50, seed=42)

    output_file = RESULTS_DIR / "phase2b_codex.jsonl"
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    # Load existing results if resuming
    existing = []
    if resume_from > 0 and output_file.exists():
        with open(output_file) as f:
            existing = [json.loads(l) for l in f if l.strip()]

    results = existing[:]
    n_pass = sum(1 for r in results if r.get("pass"))
    n_fix = sum(1 for r in results if r.get("fix_generated") or r.get("has_patch"))

    for i, idx in enumerate(indices):
        if i < resume_from:
            continue

        item = dataset[idx]
        instance_id = item["instance_id"]
        print(f"\n[{i+1}/50] {instance_id}")

        workspace = setup_workspace(item)
        try:
            result = run_codex_on_issue(item, workspace)
            results.append(result)

            fix = result.get("fix_generated") or result.get("has_patch", False)
            if fix:
                n_fix += 1
            err = result.get("error", "")
            turns = result.get("turns", 0)
            tokens = result.get("tokens", 0)

            print(f"  fix={fix} turns={turns} tokens={tokens} "
                  f"latency={result.get('total_latency_ms',0)/1000:.0f}s "
                  f"{'ERROR: '+err[:80] if err else 'ok'}")
            print(f"  Running: {n_fix}/{len(results)} fixes ({100*n_fix/len(results):.0f}%)")

        except Exception as e:
            print(f"  EXCEPTION: {e}")
            results.append({
                "instance_id": instance_id,
                "harness": "codex",
                "error": str(e)[:500],
            })
        finally:
            if Path(workspace).exists():
                shutil.rmtree(workspace, ignore_errors=True)

        # Write results after each issue
        with open(output_file, "w") as f:
            for r in results:
                f.write(json.dumps(r) + "\n")

    print(f"\n=== DONE ===")
    print(f"Total: {len(results)}")
    print(f"Fixes: {n_fix}")
    print(f"Results: {output_file}")


if __name__ == "__main__":
    main()
