#!/usr/bin/env python3
"""Analyze agent swarm Phase 1 results across all models."""
import json, sys, os
from collections import defaultdict

RESULTS_DIR = "/mnt/nvme/agent-harness/results/swarm"

models = {
    "devstral-small-2": {"file": "swarm_phase1_devstral-small-2_sera.jsonl", "label": "Devstral 24B"},
    "qwen25-coder-32b": {"file": "swarm_phase1_qwen25-coder-32b_sera.jsonl", "label": "Qwen 2.5 Coder 32B"},
    "swesmith-qwen25-32b": {"file": "swarm_phase1_swesmith-qwen25-32b_sera.jsonl", "label": "SWE-agent-LM 32B"},
    "qwen35-397b": {"file": "swarm_phase1_qwen35-397b_sera.jsonl", "label": "Qwen3.5 397B MoE"},
}

all_results = {}

for model_id, info in models.items():
    path = os.path.join(RESULTS_DIR, info["file"])
    if not os.path.exists(path):
        print(f"SKIP: {path} not found")
        continue

    results = []
    with open(path) as f:
        for line in f:
            if line.strip():
                results.append(json.loads(line))
    all_results[model_id] = results

print("=" * 80)
print("AGENT SWARM PHASE 1 — SERA HARNESS COMPARISON")
print("=" * 80)

# Per-model summary
print(f"\n{'Model':<25} {'Fix Rate':>10} {'Avg Turns':>10} {'1st Edit':>10} {'Parkinson':>10}")
print("-" * 70)

for model_id, info in models.items():
    if model_id not in all_results:
        continue
    results = all_results[model_id]
    total = len(results)
    fixes = sum(1 for r in results if r.get("fix_generated", False))
    turns = [r["turns_used"] for r in results]
    avg_turns = sum(turns) / total if total else 0

    first_edits = [r["first_edit_turn"] for r in results if (r.get("first_edit_turn") or 0) > 0]
    avg_first_edit = sum(first_edits) / len(first_edits) if first_edits else 0
    park = avg_first_edit / avg_turns * 100 if avg_turns else 0

    print(f"{info['label']:<25} {fixes}/{total} ({100*fixes/total:.0f}%){' ':>2} {avg_turns:>8.1f} {avg_first_edit:>10.1f} {park:>9.0f}%")

# Per-issue breakdown (which issues each model fixes)
print(f"\n{'='*80}")
print("PER-ISSUE BREAKDOWN (fix_generated)")
print(f"{'='*80}")

# Collect all instance IDs
all_ids = set()
for results in all_results.values():
    for r in results:
        all_ids.add(r["instance_id"])

issue_fixes = defaultdict(dict)
for model_id, results in all_results.items():
    for r in results:
        issue_fixes[r["instance_id"]][model_id] = r.get("fix_generated", False)

# Sort by instance_id
print(f"\n{'Instance':<35} {'Devstral':>8} {'Qwen25':>8} {'SWE-LM':>8} {'Qwen3.5':>8}")
print("-" * 75)

fix_counts = {m: 0 for m in models}
union_fixes = 0
all_fix = 0

for iid in sorted(all_ids):
    row = issue_fixes[iid]
    vals = {m: row.get(m, False) for m in models}
    for m, v in vals.items():
        if v: fix_counts[m] += 1
    if any(vals.values()): union_fixes += 1
    if all(vals.values()): all_fix += 1

    if any(vals.values()):
        short_id = iid.split("__")[-1] if "__" in iid else iid
        labels = ["FIX" if vals[m] else "-" for m in models]
        print(f"  {short_id:<33} {labels[0]:>8} {labels[1]:>8} {labels[2]:>8} {labels[3]:>8}")

print(f"\n{'Fixes per model:':<35} {fix_counts.get('devstral-small-2',0):>8} {fix_counts.get('qwen25-coder-32b',0):>8} {fix_counts.get('swesmith-qwen25-32b',0):>8} {fix_counts.get('qwen35-397b',0):>8}")
print(f"{'Union (any model fixes):':<35} {union_fixes:>8}")
print(f"{'Intersection (all models fix):':<35} {all_fix:>8}")

# Unique fixes
print(f"\n{'='*80}")
print("UNIQUE FIXES (only one model fixes)")
print(f"{'='*80}")
for iid in sorted(all_ids):
    row = issue_fixes[iid]
    fixes_list = [m for m in models if row.get(m, False)]
    if len(fixes_list) == 1:
        short_id = iid.split("__")[-1] if "__" in iid else iid
        label = models[fixes_list[0]]["label"]
        print(f"  {short_id}: {label}")

# Finetuning axis comparison
print(f"\n{'='*80}")
print("FINETUNING AXIS: Qwen 2.5 Coder 32B (base) vs SWE-agent-LM 32B (finetuned)")
print(f"{'='*80}")
if "qwen25-coder-32b" in all_results and "swesmith-qwen25-32b" in all_results:
    q_results = {r["instance_id"]: r for r in all_results["qwen25-coder-32b"]}
    s_results = {r["instance_id"]: r for r in all_results["swesmith-qwen25-32b"]}

    both_fix = 0
    only_base = 0
    only_ft = 0
    neither = 0

    for iid in all_ids:
        q = q_results.get(iid, {}).get("fix_generated", False)
        s = s_results.get(iid, {}).get("fix_generated", False)
        if q and s: both_fix += 1
        elif q and not s: only_base += 1
        elif not q and s: only_ft += 1
        else: neither += 1

    print(f"  Both fix:       {both_fix}")
    print(f"  Only base:      {only_base}")
    print(f"  Only finetuned: {only_ft}")
    print(f"  Neither:        {neither}")
    print(f"\n  Base fix rate:      {fix_counts['qwen25-coder-32b']}/50 ({100*fix_counts['qwen25-coder-32b']/50:.0f}%)")
    print(f"  Finetuned fix rate: {fix_counts['swesmith-qwen25-32b']}/50 ({100*fix_counts['swesmith-qwen25-32b']/50:.0f}%)")
    print(f"  Delta:              {fix_counts['swesmith-qwen25-32b'] - fix_counts['qwen25-coder-32b']:+d}pp")
