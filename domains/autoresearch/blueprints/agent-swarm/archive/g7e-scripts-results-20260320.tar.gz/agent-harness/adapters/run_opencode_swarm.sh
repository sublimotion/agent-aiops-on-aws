#!/usr/bin/env bash
# Adapter: OpenCode for swarm experiment (multi-model aware)
# Uses ENDPOINT env var for vLLM baseURL and MODEL for model name.
set -euo pipefail

# Extract base URL from ENDPOINT (strip trailing /v1 if present)
BASE_URL="${ENDPOINT%/v1}"

# Configure opencode.json with dynamic endpoint and model
cat > "$WORKSPACE/opencode.json" << OCEOF
{
  "provider": {
    "vllm": {
      "npm": "@ai-sdk/openai-compatible",
      "name": "vLLM Local",
      "options": {
        "baseURL": "${BASE_URL}/v1"
      },
      "models": {
        "${MODEL}": {
          "name": "${MODEL}",
          "limit": {
            "context": 14000,
            "output": 4000
          }
        }
      }
    }
  }
}
OCEOF

PROMPT="Fix this bug in the repo at ${WORKSPACE}.

${PROBLEM_STATEMENT}

IMPORTANT: Edit the file immediately after reading the relevant code. Do not read more than 2 files before making your edit. Use the edit tool, not bash, to modify files."

OPENCODE_API_KEY=dummy timeout 540 opencode run \
    --model "vllm/${MODEL}" \
    --format json \
    --dir "$WORKSPACE" \
    "$PROMPT" > /tmp/opencode_events_${ISSUE_ID}.json 2>/tmp/opencode_stderr_${ISSUE_ID}.log || true

python3 << 'PYEOF'
import json, sys, os, subprocess

issue_id = os.environ.get("ISSUE_ID", "unknown")
events_file = f"/tmp/opencode_events_{issue_id}.json"

total_tokens = 0
total_input = 0
total_output = 0
turns = 0
tool_calls = 0
has_edit = False
has_error = False
error_msg = ""
first_edit_turn = 0

try:
    with open(events_file) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                evt = json.loads(line)
            except json.JSONDecodeError:
                continue
            evt_type = evt.get("type", "")
            if evt_type == "step_finish":
                part = evt.get("part", {})
                tokens = part.get("tokens", {})
                total_tokens += tokens.get("total", 0)
                total_input += tokens.get("input", 0)
                total_output += tokens.get("output", 0)
                turns += 1
            elif evt_type == "tool_use":
                tool_name = evt.get("part", {}).get("tool", "")
                tool_calls += 1
                if tool_name == "edit" and first_edit_turn == 0:
                    first_edit_turn = turns + 1
                if tool_name == "edit":
                    has_edit = True
            elif evt_type == "error":
                has_error = True
                error_msg = str(evt.get("error", ""))[:300]
except FileNotFoundError:
    has_error = True
    error_msg = "no events file"

workspace = os.environ.get("WORKSPACE", "")
diff_result = subprocess.run(["git", "diff"], capture_output=True, text=True, cwd=workspace)
fix_generated = len(diff_result.stdout.strip()) > 0

result = {
    "pass": False,
    "turns": turns,
    "tokens": total_tokens,
    "input_tokens": total_input,
    "output_tokens": total_output,
    "tool_calls": tool_calls,
    "fix_generated": fix_generated,
    "has_edit": has_edit,
    "first_edit_turn": first_edit_turn,
}
if has_error:
    result["error"] = error_msg
print(json.dumps(result))
PYEOF
