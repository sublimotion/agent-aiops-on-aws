#!/usr/bin/env bash
# Adapter: DeepAgents — LangGraph with planning, sub-agents, auto-summarization
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
export OPENAI_BASE_URL="$ENDPOINT/v1"
export OPENAI_API_KEY="${OPENAI_API_KEY:-dummy}"
source /mnt/nvme/agent-harness-env/bin/activate
python3 "$SCRIPT_DIR/deepagents_agent.py" \
    --workspace "$WORKSPACE" --model "$MODEL" \
    --issue "$PROBLEM_STATEMENT" --test-cmd "$TEST_CMD" --max-turns 30
