#!/usr/bin/env python3
"""Full Phase 1 analysis: Model x Harness fix rate matrix."""
import json, os
from collections import defaultdict

RESULTS_DIR = "results/swarm"
files = [f for f in os.listdir(RESULTS_DIR) if f.startswith("swarm_phase1_") and f.endswith(".jsonl")]

all_data = {}
for fname in sorted(files):
    path = os.path.join(RESULTS_DIR, fname)
    parts = fname.replace("swarm_phase1_", "").replace(".jsonl", "")
    model = harness = None
    for h in ["sera", "opencode", "claude-code"]:
        if parts.endswith("_" + h):
            model = parts[:-(len(h)+1)]
            harness = h
            break
    if not model:
        continue
    results = []
    with open(path) as f:
        for line in f:
            if line.strip():
                results.append(json.loads(line))
    all_data[(model, harness)] = results

models = ["devstral-small-2", "qwen25-coder-32b", "swesmith-qwen25-32b", "qwen35-397b"]
harnesses = ["sera", "opencode", "claude-code"]
labels = {
    "devstral-small-2": "Devstral 24B",
    "qwen25-coder-32b": "Qwen 2.5 32B",
    "swesmith-qwen25-32b": "SWE-LM 32B",
    "qwen35-397b": "Qwen3.5 397B",
}

print("=" * 90)
print("PHASE 1: COMPLETE MODEL x HARNESS FIX RATE MATRIX")
print("=" * 90)

hdr = "{:<20} {:>12} {:>12} {:>12} {:>12}".format("Model", "SERA", "OpenCode", "ClaudeCode", "Best")
print("\n" + hdr)
print("-" * 72)

for m in models:
    cells = []
    best_rate = 0
    best_h = "—"
    for h in harnesses:
        key = (m, h)
        if key in all_data:
            results = all_data[key]
            n = len(results)
            fixes = sum(1 for r in results if r.get("fix_generated"))
            rate = fixes / n if n > 0 else 0
            cells.append("{}/{} ({:.0f}%)".format(fixes, n, 100*rate))
            if rate > best_rate:
                best_rate = rate
                best_h = h
        else:
            cells.append("—")
    print("{:<20} {:>12} {:>12} {:>12} {:>12}".format(labels.get(m, m), cells[0], cells[1], cells[2], best_h))

# Qwen3.5 SERA vs OpenCode
print("\n" + "=" * 90)
print("QWEN3.5 397B: SERA vs OPENCODE — PER-ISSUE COMPARISON")
print("=" * 90)

if ("qwen35-397b", "sera") in all_data and ("qwen35-397b", "opencode") in all_data:
    sera = {r["instance_id"]: r for r in all_data[("qwen35-397b", "sera")]}
    oc = {r["instance_id"]: r for r in all_data[("qwen35-397b", "opencode")]}
    all_ids = sorted(set(sera.keys()) | set(oc.keys()))
    
    both = only_sera = only_oc = neither = 0
    for iid in all_ids:
        s = sera.get(iid, {}).get("fix_generated", False)
        o = oc.get(iid, {}).get("fix_generated", False)
        if s and o: both += 1
        elif s: only_sera += 1
        elif o: only_oc += 1
        else: neither += 1
    
    print("  Both fix:        {}".format(both))
    print("  Only SERA:       {}".format(only_sera))
    print("  Only OpenCode:   {}".format(only_oc))
    print("  Neither:         {}".format(neither))
    print("  Union:           {}/50 ({:.0f}%)".format(both + only_sera + only_oc, 100*(both+only_sera+only_oc)/50))

# 4-model SERA comparison
print("\n" + "=" * 90)
print("4-MODEL SERA: UNION AND ENSEMBLE")
print("=" * 90)

sera_models = [m for m in models if (m, "sera") in all_data]
all_ids = set()
for m in sera_models:
    for r in all_data[(m, "sera")]:
        all_ids.add(r["instance_id"])

issue_fixes = defaultdict(dict)
for m in sera_models:
    for r in all_data[(m, "sera")]:
        issue_fixes[r["instance_id"]][m] = r.get("fix_generated", False)

fix_counts = {}
for m in sera_models:
    fix_counts[m] = sum(1 for r in all_data[(m, "sera")] if r.get("fix_generated"))

union_count = sum(1 for iid in all_ids if any(issue_fixes[iid].get(m, False) for m in sera_models))
intersection_count = sum(1 for iid in all_ids if all(issue_fixes[iid].get(m, False) for m in sera_models))
best_single = max(fix_counts.values())

for m in sera_models:
    print("  {}: {}/50 fixes".format(labels.get(m, m), fix_counts[m]))
print("  Union (any model):      {}/50 ({:.0f}%)".format(union_count, 100*union_count/50))
print("  Intersection (all):     {}/50".format(intersection_count))
print("  Headroom over best:     +{} ({:.0f}% -> {:.0f}%)".format(
    union_count - best_single, 100*best_single/50, 100*union_count/50))

# ALL configs union
print("\n" + "=" * 90)
print("FULL EXPERIMENT: ALL CONFIGS UNION")
print("=" * 90)

all_issue_fixes = defaultdict(set)  # iid -> set of (model, harness) that fix it
for (m, h), results in all_data.items():
    for r in results:
        if r.get("fix_generated"):
            all_issue_fixes[r["instance_id"]].add((m, h))

total_union = len(all_issue_fixes)
print("  Total issues with any fix: {}/50 ({:.0f}%)".format(total_union, 100*total_union/50))

# Which configs contribute unique fixes?
for (m, h), results in sorted(all_data.items()):
    fixes = sum(1 for r in results if r.get("fix_generated"))
    if fixes == 0:
        continue
    unique = 0
    for r in results:
        if r.get("fix_generated"):
            if len(all_issue_fixes[r["instance_id"]]) == 1:
                unique += 1
    if unique > 0:
        print("  {} x {}: {} unique fixes (of {} total)".format(
            labels.get(m, m), h, unique, fixes))

# Best configs ranked
print("\n" + "=" * 90)
print("RANKED CONFIGURATIONS (by fix rate)")
print("=" * 90)

configs = []
for (m, h), results in all_data.items():
    n = len(results)
    fixes = sum(1 for r in results if r.get("fix_generated"))
    if n >= 40:  # only configs with enough data
        configs.append((m, h, fixes, n))
configs.sort(key=lambda x: -x[2]/x[3])

for i, (m, h, fixes, n) in enumerate(configs, 1):
    rate = 100*fixes/n
    print("  {}. {} x {}: {}/{} ({:.0f}%)".format(i, labels.get(m, m), h, fixes, n, rate))

# Bitter Lesson
print("\n" + "=" * 90)
print("BITTER LESSON VALIDATION (fix rate)")
print("=" * 90)

# Scale: Devstral 24B -> Qwen3.5 397B (both via SERA)
d_sera = fix_counts.get("devstral-small-2", 0) / 50
q35_sera = fix_counts.get("qwen35-397b", 0) / 50
print("  Scale (SERA):      Devstral 24B ({:.0f}%) -> Qwen3.5 397B ({:.0f}%) = {:+.0f}pp".format(
    100*d_sera, 100*q35_sera, 100*(q35_sera - d_sera)))

# Scale via OpenCode
d_oc = sum(1 for r in all_data.get(("devstral-small-2", "opencode"), []) if r.get("fix_generated"))
q35_oc = sum(1 for r in all_data.get(("qwen35-397b", "opencode"), []) if r.get("fix_generated"))
print("  Scale (OpenCode):  Devstral 24B ({}/{}) -> Qwen3.5 397B ({}/{})".format(d_oc, 50, q35_oc, 50))

# Finetuning: Qwen 2.5 base -> SWE-LM (both via SERA)
base = fix_counts.get("qwen25-coder-32b", 0) / 50
ft = fix_counts.get("swesmith-qwen25-32b", 0) / 50
print("  Finetuning (SERA): Qwen 2.5 base ({:.0f}%) -> SWE-LM ({:.0f}%) = {:+.0f}pp".format(
    100*base, 100*ft, 100*(ft - base)))

# Harness spread
print("\n  Harness spread per model:")
for m in models:
    rates = []
    for h in harnesses:
        if (m, h) in all_data:
            results = all_data[(m, h)]
            n = len(results)
            if n >= 40:
                rates.append(sum(1 for r in results if r.get("fix_generated")) / n)
    if len(rates) >= 2:
        spread = (max(rates) - min(rates)) * 100
        print("    {}: {:.0f}pp spread ({})".format(
            labels.get(m, m), spread,
            ", ".join("{:.0f}%".format(100*r) for r in rates)))
