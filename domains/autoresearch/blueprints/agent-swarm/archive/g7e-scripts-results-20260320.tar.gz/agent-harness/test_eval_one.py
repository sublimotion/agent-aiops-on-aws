#!/usr/bin/env python3
"""Quick test of patch evaluation for one Django instance."""
import json, subprocess, os, re
from pathlib import Path
from datasets import load_dataset

WORKSPACE_ROOT = Path("/mnt/nvme/sera-workspaces")
REPO_CACHE = WORKSPACE_ROOT / "_repo_cache"

ds = load_dataset("princeton-nlp/SWE-bench_Lite", split="test")
instance = None
for item in ds:
    if item["instance_id"] == "django__django-15400":
        instance = item
        break

iid = instance["instance_id"]
workspace = WORKSPACE_ROOT / (iid.replace("/", "__") + "_eval")
if workspace.exists():
    subprocess.run(["rm", "-rf", str(workspace)])
cache_path = REPO_CACHE / instance["repo"].replace("/", "__")
subprocess.run(["git", "clone", str(cache_path), str(workspace)], capture_output=True, check=True)
subprocess.run(["git", "checkout", instance["base_commit"]], cwd=workspace, capture_output=True, check=True)
subprocess.run(["git", "clean", "-fdx"], cwd=workspace, capture_output=True)

patch = Path("/mnt/nvme/agent-harness/patches/langgraph__django__django-15400.patch")
r = subprocess.run(["git", "apply", str(patch)], cwd=workspace, capture_output=True, text=True)
print(f"Patch: {'OK' if r.returncode == 0 else 'FAIL ' + r.stderr[:200]}")

env = os.environ.copy()
env["PYTHONPATH"] = str(workspace)
ftp = json.loads(instance["FAIL_TO_PASS"])
print(f"Tests: {ftp}")

# Extract top-level module
modules = set()
for tid in ftp:
    m = re.match(r"\S+\s+\(([^)]+)\)", tid)
    if m:
        modules.add(m.group(1).split(".")[0])

labels = " ".join(sorted(modules))
cmd = f"python tests/runtests.py {labels} --verbosity 0"
print(f"Cmd: {cmd}")
r = subprocess.run(cmd, shell=True, cwd=str(workspace), capture_output=True, text=True, timeout=120, env=env)
print(f"RC: {r.returncode}")
out = r.stdout + r.stderr
print(out[-500:])
