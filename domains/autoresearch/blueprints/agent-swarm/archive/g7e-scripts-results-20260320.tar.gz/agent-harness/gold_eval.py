#!/usr/bin/env python3
"""
Gold test evaluation for agent swarm results.

Re-runs the SERA agent loop for issues that generated fixes,
saves patches, applies gold test_patch, runs FAIL_TO_PASS tests.

Usage:
    python3 gold_eval.py --input results/swarm/swarm_phase1_qwen25-coder-32b_sera.jsonl \
                         --output results/swarm/eval_qwen25-coder-32b_sera.jsonl \
                         --endpoint http://localhost:8000
"""

import argparse
import asyncio
import json
import logging
import os
import subprocess
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path

sys.path.insert(0, "/mnt/nvme/agent-harness-scripts")
from harness_eval import (
    Issue, load_subset, setup_workspace, _get_git_diff,
    run_instrumented_loop, PHASE1_CONFIGS,
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger(__name__)

WORKSPACE_ROOT = Path("/mnt/nvme/gold-eval-workspaces")


@dataclass
class GoldResult:
    instance_id: str
    model: str
    harness: str
    fix_generated: bool
    patch_applied: bool
    gold_tests_pass: bool
    test_output: str
    turns_used: int
    error: str = ""


def run_gold_tests(workspace: str, issue: Issue) -> tuple[bool, str]:
    """Apply gold test_patch and run FAIL_TO_PASS tests."""
    if not issue.test_patch:
        return False, "No test_patch available"

    # First commit the agent's changes so gold patch applies cleanly
    subprocess.run(
        "git add -A && git commit -m 'agent fix' --allow-empty",
        cwd=workspace, shell=True, capture_output=True,
    )

    # Apply gold test patch
    result = subprocess.run(
        ["git", "apply", "--allow-empty", "-"],
        cwd=workspace, input=issue.test_patch,
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        # Try with --3way
        result = subprocess.run(
            ["git", "apply", "--allow-empty", "--3way", "-"],
            cwd=workspace, input=issue.test_patch,
            capture_output=True, text=True,
        )
        if result.returncode != 0:
            # Last resort: try with --reject to see what applies
            result = subprocess.run(
                ["git", "apply", "--allow-empty", "--reject", "-"],
                cwd=workspace, input=issue.test_patch,
                capture_output=True, text=True,
            )
            if result.returncode != 0:
                return False, f"Gold patch failed: {result.stderr[:200]}"

    # Commit test patch
    subprocess.run(
        "git add -A && git commit -m 'apply test patch' --allow-empty",
        cwd=workspace, shell=True, capture_output=True,
    )

    # Run the test command
    try:
        test_result = subprocess.run(
            issue.test_cmd, cwd=workspace, shell=True,
            capture_output=True, text=True, timeout=180,
        )
        output = test_result.stdout + "\n" + test_result.stderr
        # Check for pass indicators
        passed = test_result.returncode == 0
        if not passed:
            # Some test frameworks return non-zero but tests pass
            # Check for common pass patterns
            if "passed" in output.lower() and "failed" not in output.lower():
                passed = True
            elif "OK" in output and "FAIL" not in output:
                passed = True
        return passed, output[-500:]  # last 500 chars
    except subprocess.TimeoutExpired:
        return False, "Test timeout (180s)"
    except Exception as e:
        return False, f"Test error: {e}"


async def evaluate_one(issue: Issue, endpoint: str, model: str, config: dict, config_name: str) -> GoldResult:
    """Re-run SERA for one issue, save patch, run gold tests."""
    import aiohttp

    workspace = str(WORKSPACE_ROOT / issue.instance_id.replace("/", "_"))
    result = GoldResult(
        instance_id=issue.instance_id,
        model=model,
        harness=config_name,
        fix_generated=False,
        patch_applied=False,
        gold_tests_pass=False,
        test_output="",
        turns_used=0,
    )

    try:
        workspace = setup_workspace(issue, str(WORKSPACE_ROOT))
    except Exception as e:
        result.error = f"Workspace setup failed: {e}"
        return result

    try:
        connector = aiohttp.TCPConnector(limit=10, force_close=True)
        async with aiohttp.ClientSession(connector=connector) as session:
            eval_result = await run_instrumented_loop(
                session, endpoint, model, issue, workspace, config, config_name,
            )
            result.turns_used = eval_result.turns_used
    except Exception as e:
        result.error = f"SERA loop failed: {e}"
        return result

    # Check if fix was generated
    diff = _get_git_diff(workspace)
    result.fix_generated = bool(diff)

    if not diff:
        return result

    # Save patch
    patch_dir = WORKSPACE_ROOT / "patches"
    patch_dir.mkdir(exist_ok=True)
    patch_file = patch_dir / f"{model}__{issue.instance_id.replace('/', '_')}.patch"
    patch_file.write_text(diff)

    result.patch_applied = True

    # Run gold tests
    passed, output = run_gold_tests(workspace, issue)
    result.gold_tests_pass = passed
    result.test_output = output

    return result


async def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, help="Input JSONL from swarm eval")
    parser.add_argument("--output", required=True, help="Output JSONL for gold eval results")
    parser.add_argument("--endpoint", required=True, help="vLLM endpoint URL")
    parser.add_argument("--model", default=None, help="Model name (auto-detected from input)")
    args = parser.parse_args()

    # Load input results, filter to fix_generated=True
    issues_to_eval = []
    model_name = args.model
    harness_name = None
    with open(args.input) as f:
        for line in f:
            r = json.loads(line)
            if not model_name:
                model_name = r["model"]
            if not harness_name:
                harness_name = r["harness"]
            if r["fix_generated"]:
                issues_to_eval.append(r["instance_id"])

    log.info(f"Model: {model_name}, Harness: {harness_name}")
    log.info(f"Issues with fixes: {len(issues_to_eval)} / 50")

    # Load SWE-bench issues
    all_issues = load_subset()
    issue_map = {i.instance_id: i for i in all_issues}

    # SERA config
    config = {"max_turns": 30, "strategy": "baseline", "restart_at": 0, "compact_at": 0}

    WORKSPACE_ROOT.mkdir(parents=True, exist_ok=True)

    results = []

    # Resume support
    completed = set()
    if os.path.exists(args.output):
        with open(args.output) as f:
            for line in f:
                if line.strip():
                    r = json.loads(line)
                    completed.add(r["instance_id"])
                    results.append(r)
        log.info(f"Resuming from {len(completed)} completed evaluations")

    for i, iid in enumerate(issues_to_eval):
        if iid in completed:
            log.info(f"  [{i+1}/{len(issues_to_eval)}] {iid} — skipped (done)")
            continue

        if iid not in issue_map:
            log.warning(f"  [{i+1}/{len(issues_to_eval)}] {iid} — not in subset, skipping")
            continue

        issue = issue_map[iid]
        log.info(f"  [{i+1}/{len(issues_to_eval)}] {iid}")

        result = await evaluate_one(issue, args.endpoint, model_name, config, harness_name)

        status = "PASS" if result.gold_tests_pass else ("FIX" if result.fix_generated else "FAIL")
        log.info(f"    {status} (turns={result.turns_used})")

        results.append(asdict(result))

        # Incremental write
        with open(args.output, "a") as f:
            f.write(json.dumps(asdict(result)) + "\n")

    # Summary
    total = len(results)
    fixes = sum(1 for r in results if r["fix_generated"])
    passes = sum(1 for r in results if r["gold_tests_pass"])
    log.info(f"\n=== Gold Eval Summary ===")
    log.info(f"  Issues evaluated: {total}")
    log.info(f"  Fixes generated: {fixes}")
    log.info(f"  Gold tests pass: {passes}/{total} ({100*passes/total if total else 0:.0f}%)")
    log.info(f"  Precision: {passes}/{fixes} ({100*passes/fixes if fixes else 0:.0f}%)")


if __name__ == "__main__":
    asyncio.run(main())
