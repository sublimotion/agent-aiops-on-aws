#!/usr/bin/env python3
import json

def load_eval(path):
    results = {}
    for line in open(path):
        r = json.loads(line)
        results[r["instance_id"]] = r.get("tests_pass", False)
    return results

ohmypi = load_eval("results/eval_ohmypi.jsonl")
langgraph = load_eval("results/eval_langgraph.jsonl")
sera = load_eval("results/eval_sera.jsonl")

all_ids = sorted(set(list(ohmypi.keys()) + list(langgraph.keys()) + list(sera.keys())))

print(f"{'instance_id':45s} {'HL':4s} {'LG':4s} {'SE':4s}")
print("-" * 57)
for iid in all_ids:
    oh = ohmypi.get(iid)
    lg = langgraph.get(iid)
    se = sera.get(iid)
    if oh or lg or se:
        oh_s = "P" if oh else ("F" if iid in ohmypi else "-")
        lg_s = "P" if lg else ("F" if iid in langgraph else "-")
        se_s = "P" if se else ("F" if iid in sera else "-")
        print(f"{iid:45s} {oh_s:4s} {lg_s:4s} {se_s:4s}")

oh_p = sum(1 for v in ohmypi.values() if v)
lg_p = sum(1 for v in langgraph.values() if v)
se_p = sum(1 for v in sera.values() if v)
union = sum(1 for iid in all_ids if ohmypi.get(iid) or langgraph.get(iid) or sera.get(iid))
oh_only = [iid for iid in all_ids if ohmypi.get(iid) and not langgraph.get(iid) and not sera.get(iid)]
lg_only = [iid for iid in all_ids if langgraph.get(iid) and not ohmypi.get(iid) and not sera.get(iid)]
se_only = [iid for iid in all_ids if sera.get(iid) and not ohmypi.get(iid) and not langgraph.get(iid)]

print(f"\nHashline (ohmypi): {oh_p}/50 ({100*oh_p/50:.0f}%)")
print(f"LangGraph:         {lg_p}/50 ({100*lg_p/50:.0f}%)")
print(f"SERA:              {se_p}/50 ({100*se_p/50:.0f}%)")
print(f"Union (any):       {union}/50 ({100*union/50:.0f}%)")
print(f"\nHashline-only: {oh_only}")
print(f"LangGraph-only: {lg_only}")
print(f"SERA-only: {se_only}")
