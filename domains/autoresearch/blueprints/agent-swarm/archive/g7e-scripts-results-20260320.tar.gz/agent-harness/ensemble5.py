import json

harnesses = {"sera": set(), "langgraph": set(), "ohmypi": set(), "piagent": set(), "opencode": set()}
for h in harnesses:
    fname = "results/eval_{}.jsonl".format(h)
    try:
        with open(fname) as f:
            for line in f:
                d = json.loads(line)
                if d.get("tests_pass"):
                    harnesses[h].add(d["instance_id"])
    except FileNotFoundError:
        pass

print("=== Individual Pass Rates ===")
for h in sorted(harnesses, key=lambda x: len(harnesses[x]), reverse=True):
    print("  {}: {}/50 ({}%)".format(h, len(harnesses[h]), len(harnesses[h])*2))

union = set()
for h in harnesses:
    union |= harnesses[h]
print("\n=== 5-Harness Ensemble ===")
print("  Union: {}/50 ({}%)".format(len(union), len(union)*2))

# Per-issue breakdown
print("\n=== Per-Issue Breakdown ===")
for iid in sorted(union):
    passes = [h for h in sorted(harnesses) if iid in harnesses[h]]
    print("  {}: {}".format(iid, ", ".join(passes)))

# Unique passes
print("\n=== Unique Passes ===")
for h in sorted(harnesses):
    others = set()
    for h2 in harnesses:
        if h2 != h:
            others |= harnesses[h2]
    unique = harnesses[h] - others
    if unique:
        print("  {}: {}".format(h, sorted(unique)))
    else:
        print("  {}: none unique".format(h))
