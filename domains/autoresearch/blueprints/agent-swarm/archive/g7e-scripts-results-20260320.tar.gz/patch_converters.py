path = "/usr/local/lib/python3.12/dist-packages/mistral_common/protocol/instruct/converters.py"
with open(path) as f:
    code = f.read()

old = '        elif message_role == "system":\n            message = SystemMessage.from_openai(openai_message)'

new = '''        elif message_role in ("system", "developer"):
            msg = {k: v for k, v in openai_message.items() if k in ("role", "content")}
            msg["role"] = "system"
            c = msg.get("content")
            if isinstance(c, list):
                parts = []
                for p in c:
                    if isinstance(p, dict):
                        parts.append(p.get("text", ""))
                    else:
                        parts.append(str(p))
                msg["content"] = "\\n".join(parts)
            message = SystemMessage.from_openai(msg)'''

if old in code:
    code = code.replace(old, new)
    with open(path, "w") as f:
        f.write(code)
    print("Patch 1 (system/developer) applied")

old2 = '        if message_role == "user":\n            message = UserMessage.from_openai(openai_message)'
new2 = '''        if message_role == "user":
            msg = {k: v for k, v in openai_message.items() if k in ("role", "content")}
            c = msg.get("content")
            if isinstance(c, list):
                parts = []
                for p in c:
                    if isinstance(p, dict):
                        parts.append(p.get("text", ""))
                    elif isinstance(p, str):
                        parts.append(p)
                msg["content"] = "\\n".join(parts) if parts else ""
            message = UserMessage.from_openai(msg)'''
if old2 in code:
    code = code.replace(old2, new2)
    with open(path, "w") as f:
        f.write(code)
    print("Patch 2 (user messages) applied")
